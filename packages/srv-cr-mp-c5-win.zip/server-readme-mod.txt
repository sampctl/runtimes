
http://www.sa-mp.com/
http://www.sampsrv.ru/

Server version:
	San Andreas Multiplayer 0.3.7 R2-1-1 server (CR-MP 0.3.7 C5 server)
	
Client version:
	San Andreas Multiplayer 0.3.7 client for GTA Criminal Russia (CR-MP 0.3.7 Beta-Testing 2.4)